﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp32
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = CreateString();
            Console.WriteLine(str);
            int sum = FindSum(str);
            Console.WriteLine(sum);
        }

        static string CreateString()
        {
            string str = "101 505 80 904 840151 4540 8840 1";
            return str;
        }

        static int FindSum(string str)
        {
            string[] array = str.Split();
            int sum = 0;
            for(int i = 0; i < array.Length; i++)
            {
                sum += Convert.ToInt32(array[i]);
            }
            return sum;
        }
    }
}
